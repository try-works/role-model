import { readFileSync } from "node:fs";

import type { CompactTaxonomy } from "./compact-data.js";

const readCompactJson = <T>(fileName: string): T =>
  JSON.parse(
    readFileSync(new URL(`../../data/taxonomy/${fileName}`, import.meta.url), "utf8"),
  ) as T;

export function loadCompactTaxonomy(): CompactTaxonomy {
  return {
    manifest: readCompactJson<CompactTaxonomy["manifest"]>("compact-manifest.json"),
    groups: readCompactJson<CompactTaxonomy["groups"]>("compact-groups.json"),
    roleSummaries: readCompactJson<CompactTaxonomy["roleSummaries"]>(
      "compact-role-summaries.json",
    ),
    roleTaskIndex: readCompactJson<CompactTaxonomy["roleTaskIndex"]>(
      "compact-role-task-index.json",
    ),
  };
}
