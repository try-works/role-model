import { classifyWithProgressiveDisclosure } from "./taxonomy/classify-with-progressive-disclosure.js";
import type { CompactTaxonomy } from "./taxonomy/compact-data.js";

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function hasRoleModelIntent(payload: Record<string, unknown>): boolean {
  return isRecord(payload.role_model) && isRecord(payload.role_model.intent);
}

function textFromContent(content: unknown): string {
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content
    .map((part) => {
      if (typeof part === "string") return part;
      if (isRecord(part) && typeof part.text === "string") return part.text;
      return "";
    })
    .filter(Boolean)
    .join("\n");
}

function promptFromMessages(messages: unknown): string {
  if (!Array.isArray(messages)) return "";
  for (const message of [...messages].reverse()) {
    if (!isRecord(message) || message.role !== "user") continue;
    const text = textFromContent(message.content);
    if (text.trim()) return text;
  }
  return "";
}

export function injectRoleModelIntentIntoPayload(
  payload: unknown,
  roleModelAliasIds: ReadonlySet<string>,
  taxonomy?: CompactTaxonomy,
): unknown {
  if (!isRecord(payload)) return payload;
  const model = typeof payload.model === "string" ? payload.model : "";
  const normalizedModel = model.startsWith("role-model/") ? model.slice("role-model/".length) : model;
  if (!roleModelAliasIds.has(normalizedModel)) return payload;
  if (hasRoleModelIntent(payload)) return payload;

  const prompt = promptFromMessages(payload.messages);
  if (!prompt.trim()) return payload;

  return {
    ...payload,
    role_model: classifyWithProgressiveDisclosure({ prompt, taxonomy }).role_model,
  };
}
