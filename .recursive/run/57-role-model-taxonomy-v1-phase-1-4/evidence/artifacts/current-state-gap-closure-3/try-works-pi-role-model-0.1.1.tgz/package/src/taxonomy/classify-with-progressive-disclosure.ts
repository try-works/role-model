import { loadCompactTaxonomy } from "./load-compact-taxonomy.js";
import type { CompactTaxonomy } from "./compact-data.js";

export interface ProgressiveClassificationInput {
  readonly prompt: string;
  readonly taxonomy?: CompactTaxonomy;
}

export interface ProgressiveClassification {
  readonly role_model: {
    readonly contract_version: 1;
    readonly intent: {
      readonly taxonomy_version: string;
      readonly content_revision: string;
      readonly classification_contract_version: string;
      readonly classification_version: string;
      readonly source: "heuristic";
      readonly confidence: number;
      readonly role_hint_id: string;
      readonly role_source: "heuristic";
      readonly task_type: string;
      readonly task_action: string;
      readonly task_variant: string | null;
      readonly task_source: "heuristic";
      readonly task_confidence: number;
      readonly preferred_capabilities: readonly string[];
      readonly required_modalities: readonly string[];
      readonly output_modalities: readonly string[];
      readonly tool_classes: readonly string[];
      readonly context_tokens_estimate: number;
      readonly evidence: readonly string[];
      readonly alternatives: readonly { readonly role_hint_id: string; readonly task_type: string }[];
    };
  };
  readonly candidateGroupIds: readonly string[];
  readonly candidateRoleIds: readonly string[];
  readonly loadedChunks: readonly string[];
  readonly hiddenModelCallUsed: false;
}

const rules: readonly {
  readonly pattern: RegExp;
  readonly evidence: string;
  readonly roleId: string;
  readonly taskType: string;
  readonly capabilities: readonly string[];
  readonly toolClasses: readonly string[];
}[] = [
  {
    pattern: /\b(implement|bug fix|fix|patch|regression test)\b/i,
    evidence: "implementation/fix signal",
    roleId: "coder",
    taskType: "coder.edit",
    capabilities: ["code.read", "code.write"],
    toolClasses: ["filesystem.read", "filesystem.write", "shell.execute"],
  },
  {
    pattern: /\b(security|risk|vulnerab|threat|diff)\b/i,
    evidence: "security/risk/diff signal",
    roleId: "security",
    taskType: "security.audit",
    capabilities: ["security.analysis", "code.read"],
    toolClasses: ["filesystem.read"],
  },
  {
    pattern: /\b(current|public documentation|cite|compare|sources?)\b/i,
    evidence: "current research/citation signal",
    roleId: "researcher",
    taskType: "researcher.web_research.current",
    capabilities: ["web.search", "citation.synthesis"],
    toolClasses: ["web.search", "http.fetch"],
  },
  {
    pattern: /\b(support notes|customer reply|ticket|apology)\b/i,
    evidence: "support communication signal",
    roleId: "support",
    taskType: "support.ticket.reply",
    capabilities: ["communication.user_facing"],
    toolClasses: [],
  },
  {
    pattern: /\b(schema|migration plan|api design|architecture)\b/i,
    evidence: "architecture/schema migration signal",
    roleId: "architect",
    taskType: "architect.migration.strategy",
    capabilities: ["reasoning.multi_step", "data.schema"],
    toolClasses: [],
  },
  {
    pattern: /\b(product requirements|acceptance criteria|workflow)\b/i,
    evidence: "product requirements signal",
    roleId: "product",
    taskType: "product.requirements",
    capabilities: ["reasoning.multi_step"],
    toolClasses: [],
  },
];

export function classifyWithProgressiveDisclosure(
  input: ProgressiveClassificationInput,
): ProgressiveClassification {
  const taxonomy = input.taxonomy ?? loadCompactTaxonomy();
  const normalizedPrompt = input.prompt.trim();
  const match = rules.find((rule) => rule.pattern.test(normalizedPrompt)) ?? rules[1];
  const roleSummary = taxonomy.roleSummaries.find((role) => role.id === match.roleId);
  const roleTasks = taxonomy.roleTaskIndex[match.roleId] ?? [];
  const alternatives = roleTasks
    .filter((task) => task.id !== match.taskType)
    .slice(0, 2)
    .map((task) => ({ role_hint_id: match.roleId, task_type: task.id }));
  const taskParts = match.taskType.split(".").slice(1);

  return {
    role_model: {
      contract_version: 1,
      intent: {
        taxonomy_version: taxonomy.manifest.taxonomyVersion,
        content_revision: taxonomy.manifest.contentRevision,
        classification_contract_version: taxonomy.manifest.classificationContractVersion,
        classification_version: "role-model.pi-classifier.v1",
        source: "heuristic",
        confidence: 0.72,
        role_hint_id: match.roleId,
        role_source: "heuristic",
        task_type: match.taskType,
        task_action: taskParts[0] ?? match.taskType,
        task_variant: taskParts.length > 1 ? taskParts.slice(1).join(".") : null,
        task_source: "heuristic",
        task_confidence: 0.72,
        preferred_capabilities: match.capabilities,
        required_modalities: ["text"],
        output_modalities: ["text"],
        tool_classes: match.toolClasses,
        context_tokens_estimate: Math.max(1, Math.ceil(normalizedPrompt.length / 4)),
        evidence: [match.evidence],
        alternatives,
      },
    },
    candidateGroupIds: roleSummary?.primaryGroupId ? [roleSummary.primaryGroupId] : [],
    candidateRoleIds: [match.roleId],
    loadedChunks: ["groups", `roles:${match.roleId}`, `tasks:${match.roleId}`],
    hiddenModelCallUsed: false,
  };
}
