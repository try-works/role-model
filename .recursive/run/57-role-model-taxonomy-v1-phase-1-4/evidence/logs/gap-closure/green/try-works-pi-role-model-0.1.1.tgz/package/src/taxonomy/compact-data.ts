export interface CompactTaxonomy {
  readonly manifest: {
    readonly taxonomyVersion: string;
    readonly contentRevision: string;
    readonly classificationContractVersion: string;
    readonly counts: {
      readonly groups: number;
      readonly roles: number;
      readonly tasks: number;
    };
  };
  readonly groups: readonly {
    readonly id: string;
    readonly label: string;
    readonly primaryRoleIds: readonly string[];
    readonly secondaryRoleIds: readonly string[];
  }[];
  readonly roleSummaries: readonly {
    readonly id: string;
    readonly label: string;
    readonly primaryGroupId: string;
    readonly secondaryGroupIds: readonly string[];
  }[];
  readonly roleTaskIndex: Record<
    string,
    readonly {
      readonly id: string;
      readonly label: string;
      readonly primaryRole: string;
      readonly compatibleRoles: readonly string[];
      readonly requiredCapabilities: readonly string[];
      readonly preferredCapabilities: readonly string[];
      readonly requiredModalities: readonly string[];
      readonly toolClasses: readonly string[];
      readonly variants: readonly string[];
    }[]
  >;
}

const rolesByGroup = {
  engineering: ["coder", "architect", "operator", "tester", "security", "data"],
  product_design: ["product", "designer", "planner", "analyst"],
  knowledge_research: ["researcher", "knowledge", "scientist", "mathematician", "educator"],
  business: ["strategist", "marketer", "seller", "finance", "procurement"],
  communication: ["writer", "translator", "creative", "support", "coordinator"],
  governance_safety: ["legal", "health", "recruiter"],
} as const;

const secondaryGroups: Record<string, readonly string[]> = {
  security: ["governance_safety"],
  legal: ["business"],
  finance: ["governance_safety"],
  recruiter: ["business"],
  health: ["knowledge_research"],
};

const label = (id: string): string =>
  id
    .split(/[._-]+/)
    .filter(Boolean)
    .map((part) => `${part.slice(0, 1).toUpperCase()}${part.slice(1)}`)
    .join(" ");

const taskSuffixesByRole: Record<string, readonly string[]> = {
  coder: ["edit", "review", "debug.root_cause", "test.write", "refactor", "explain", "migrate", "generate", "dependency.update", "config"],
  architect: ["design", "review", "plan", "api_design", "infrastructure.design", "data_model", "integration.plan", "scalability.review", "migration.strategy", "adr.write"],
  security: ["audit", "audit.supply_chain", "threat_model", "vulnerability_triage", "policy_review", "secrets.scan", "auth.review", "privacy.review", "incident.review", "safe_prompt.review"],
  researcher: ["web_research", "web_research.current", "compare_sources", "literature_review", "fact_check", "source_find", "timeline.build", "market_scan", "standards_lookup", "document_extract"],
  writer: ["docs.write", "docs.public", "docs.edit", "summarize", "release_notes", "email.write", "blog.write", "proposal.write", "style.rewrite", "outline"],
  operator: ["debug.startup", "debug.ui", "debug.api", "deploy.review", "incident_triage", "config", "install", "monitor", "backup.restore", "release.execute"],
  analyst: ["compare", "evaluate", "prioritize", "metrics.define", "risk.assess", "root_cause", "report.write", "data_interpret", "decision_matrix", "trend.analyze"],
  planner: ["requirements", "roadmap", "roadmap.release", "decompose", "milestone", "sprint.plan", "acceptance.criteria", "rollout", "dependency.map", "resource.plan"],
  tester: ["e2e", "plan", "regression", "reproduce", "unit.plan", "integration.plan", "accessibility", "performance", "security", "acceptance"],
  data: ["query", "schema.review", "transform", "analyze", "visualize", "validate", "extract", "join", "quality.audit", "metric.define"],
  product: ["requirements", "workflow.review", "release_notes", "spec.write", "user_story", "acceptance", "prd.write", "feature.prioritize", "feedback.synthesize", "launch.readiness"],
  designer: ["ui.review", "interaction", "visual_direction", "prototype", "design_system", "accessibility.review", "content.layout", "usability.test", "mobile.responsive", "visual.qa"],
  support: ["triage", "explain", "escalate", "ticket.reply", "runbook.write", "issue.reproduce", "knowledge_base.suggest", "status.update", "customer.apology", "faq.write"],
  legal: ["review", "compliance_check", "privacy.review", "terms.review", "license.review", "contract.summarize", "risk.issue_spot", "policy.draft", "retention.review", "accessibility.compliance"],
  finance: ["cost_estimate", "compare_options", "invoice.review", "budget.plan", "forecast", "unit_economics", "pricing.model", "variance.analyze", "procurement.cost", "roi.calculate"],
  creative: ["brainstorm", "copywriting", "storyboard", "name.generate", "concept.develop", "script.write", "brand.voice", "visual.prompt", "tagline", "social.post"],
  educator: ["tutor", "lesson.plan", "quiz.generate", "feedback", "curriculum.design", "study.plan", "example.generate", "rubric.create", "concept.explain", "practice.review"],
  translator: ["translate", "localize.locale", "review", "tone.adapt", "glossary.create", "subtitles.translate", "technical.translate", "back_translate", "locale.review", "multilingual.reply"],
  marketer: ["positioning", "campaign.plan", "content.seo", "copy.ad", "audience.research", "email.sequence", "landing_page.copy", "social.plan", "messaging.review", "launch.plan"],
  seller: ["discovery.plan", "outreach.write", "proposal.enterprise", "objection.handle", "account.plan", "demo.script", "follow_up.write", "competitor.battlecard", "call.summary", "mutual_action_plan"],
  recruiter: ["job_description", "interview.plan", "candidate.screen", "sourcing.message", "scorecard.create", "interview.feedback", "offer.prepare", "pipeline.update", "role.intake", "candidate.compare"],
  procurement: ["vendor.compare", "rfp.write", "requirements", "contract.commercial", "security.questionnaire", "vendor.scorecard", "renewal.review", "sla.review", "negotiation.plan", "purchase.justification"],
  coordinator: ["meeting.agenda", "meeting.notes", "schedule.plan", "follow_up", "task.plan", "inbox.triage", "decision.log", "project.status", "reminder.plan", "handoff.prepare"],
  knowledge: ["organize", "retrieve", "memory.update", "kb.write", "note.summarize", "taxonomy.design", "link.map", "runbook.update", "archive.clean", "context.brief"],
  strategist: ["business.plan", "market.analyze", "competitive.review", "risk.scenario", "swot", "okr.define", "board.brief", "operating.model", "pricing.strategy", "partnership.evaluate"],
  mathematician: ["solve", "verify", "model", "explain", "statistics.analyze", "optimize", "proof.write", "formula.derive", "simulation.plan", "error.check"],
  scientist: ["experiment.design", "evidence.review", "method.critique", "literature.synthesize", "hypothesis.formulate", "protocol.write", "data.interpret", "peer_review", "safety.review", "technical.explain"],
  health: ["info.general", "info.safety", "care_navigation", "wellness.plan", "medication.info", "appointment.prepare", "symptom.organize", "exercise.general", "nutrition.general", "mental_wellness.info"],
};

const compactTaskOverrides: Record<string, Record<string, unknown>> = {
  "coder.edit": { label: "Code Edit" },
  "coder.review": {
    label: "Code Review",
    compatibleRoles: ["coder", "security", "architect"],
    requiredCapabilities: ["code.read"],
  },
  "operator.install": {
    label: "Installation",
    compatibleRoles: ["operator", "coder", "support"],
    requiredCapabilities: ["tools.function_calling"],
  },
};

const roleTaskIds = Object.fromEntries(
  Object.entries(taskSuffixesByRole).map(([roleId, suffixes]) => [
    roleId,
    suffixes.map((suffix) => `${roleId}.${suffix}`),
  ]),
) as Record<string, readonly string[]>;

const roleSummaries = Object.entries(rolesByGroup).flatMap(([groupId, roleIds]) =>
  roleIds.map((roleId) => ({
    id: roleId,
    label: label(roleId),
    primaryGroupId: groupId,
    secondaryGroupIds: secondaryGroups[roleId] ?? [],
  })),
);

export const compactTaxonomy: CompactTaxonomy = {
  manifest: {
    taxonomyVersion: "1.0.0-alpha.1",
    contentRevision: "taxonomy-v1-alpha.1",
    classificationContractVersion: "role-model.classification.v1",
    counts: {
      groups: Object.keys(rolesByGroup).length,
      roles: roleSummaries.length,
      tasks: Object.values(roleTaskIds).reduce((sum, taskIds) => sum + taskIds.length, 0),
    },
  },
  groups: [
    {
      id: "engineering",
      label: "Engineering",
      primaryRoleIds: rolesByGroup.engineering,
      secondaryRoleIds: [],
    },
    {
      id: "product_design",
      label: "Product And Design",
      primaryRoleIds: rolesByGroup.product_design,
      secondaryRoleIds: [],
    },
    {
      id: "knowledge_research",
      label: "Knowledge And Research",
      primaryRoleIds: rolesByGroup.knowledge_research,
      secondaryRoleIds: ["health"],
    },
    {
      id: "business",
      label: "Business",
      primaryRoleIds: rolesByGroup.business,
      secondaryRoleIds: ["legal", "recruiter"],
    },
    {
      id: "communication",
      label: "Communication",
      primaryRoleIds: rolesByGroup.communication,
      secondaryRoleIds: [],
    },
    {
      id: "governance_safety",
      label: "Governance And Safety",
      primaryRoleIds: rolesByGroup.governance_safety,
      secondaryRoleIds: ["security", "finance"],
    },
  ],
  roleSummaries,
  roleTaskIndex: Object.fromEntries(
    Object.entries(roleTaskIds).map(([roleId, taskIds]) => [
      roleId,
      taskIds.map((id) => ({
        id,
        label: label(id),
        primaryRole: roleId,
        compatibleRoles: [roleId],
        requiredCapabilities: [],
        preferredCapabilities: [],
        requiredModalities: ["text"],
        toolClasses: [],
        variants: id.split(".").slice(2),
        ...(compactTaskOverrides[id] ?? {}),
      })),
    ]),
  ),
};
