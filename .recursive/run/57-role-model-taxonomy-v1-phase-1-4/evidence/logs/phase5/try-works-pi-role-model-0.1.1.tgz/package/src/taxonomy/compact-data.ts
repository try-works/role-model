export interface CompactTaxonomy {
  readonly manifest: {
    readonly taxonomyVersion: string;
    readonly contentRevision: string;
    readonly classificationContractVersion: string;
    readonly counts: {
      readonly groups: number;
      readonly roles: number;
      readonly tasks: number;
    };
  };
  readonly groups: readonly {
    readonly id: string;
    readonly label: string;
    readonly primaryRoleIds: readonly string[];
    readonly secondaryRoleIds: readonly string[];
  }[];
  readonly roleSummaries: readonly {
    readonly id: string;
    readonly label: string;
    readonly primaryGroupId: string;
    readonly secondaryGroupIds: readonly string[];
  }[];
  readonly roleTaskIndex: Record<string, readonly { readonly id: string; readonly label: string }[]>;
}

const rolesByGroup = {
  engineering: ["coder", "architect", "operator", "tester", "security", "data"],
  product_design: ["product", "designer", "planner", "analyst"],
  knowledge_research: ["researcher", "knowledge", "scientist", "mathematician", "educator"],
  business: ["strategist", "marketer", "seller", "finance", "procurement"],
  communication: ["writer", "translator", "creative", "support", "coordinator"],
  governance_safety: ["legal", "health", "recruiter"],
} as const;

const secondaryGroups: Record<string, readonly string[]> = {
  security: ["governance_safety"],
  legal: ["business"],
  finance: ["governance_safety"],
  recruiter: ["business"],
  health: ["knowledge_research"],
};

const label = (id: string): string =>
  id
    .split(/[._-]+/)
    .filter(Boolean)
    .map((part) => `${part.slice(0, 1).toUpperCase()}${part.slice(1)}`)
    .join(" ");

const roleTaskIds: Record<string, readonly string[]> = {
  coder: ["coder.edit", "coder.review", "coder.debug.root_cause", "coder.test.write"],
  architect: ["architect.design", "architect.review", "architect.plan", "architect.migration.strategy"],
  security: ["security.audit", "security.audit.supply_chain", "security.threat_model"],
  researcher: ["researcher.web_research", "researcher.web_research.current", "researcher.compare_sources"],
  writer: ["writer.docs.write", "writer.docs.public", "writer.docs.edit"],
  operator: ["operator.debug.startup", "operator.debug.ui", "operator.install"],
  analyst: ["analyst.compare", "analyst.evaluate", "analyst.prioritize"],
  planner: ["planner.requirements", "planner.roadmap", "planner.acceptance.criteria"],
  tester: ["tester.e2e", "tester.plan", "tester.regression"],
  data: ["data.query", "data.schema.review", "data.transform"],
  product: ["product.requirements", "product.workflow.review", "product.acceptance"],
  designer: ["designer.ui.review", "designer.interaction", "designer.visual.qa"],
  support: ["support.triage", "support.ticket.reply", "support.explain"],
  legal: ["legal.review", "legal.compliance_check", "legal.license.review"],
  finance: ["finance.cost_estimate", "finance.compare_options", "finance.budget.plan"],
  creative: ["creative.brainstorm", "creative.copywriting", "creative.storyboard"],
  educator: ["educator.tutor", "educator.lesson.plan", "educator.quiz.generate"],
  translator: ["translator.translate", "translator.localize.locale", "translator.review"],
  marketer: ["marketer.positioning", "marketer.campaign.plan", "marketer.content.seo"],
  seller: ["seller.discovery.plan", "seller.outreach.write", "seller.proposal.enterprise"],
  recruiter: ["recruiter.job_description", "recruiter.interview.plan", "recruiter.candidate.screen"],
  procurement: ["procurement.vendor.compare", "procurement.rfp.write", "procurement.requirements"],
  coordinator: ["coordinator.meeting.agenda", "coordinator.meeting.notes", "coordinator.follow_up"],
  knowledge: ["knowledge.organize", "knowledge.retrieve", "knowledge.memory.update"],
  strategist: ["strategist.business.plan", "strategist.market.analyze", "strategist.swot"],
  mathematician: ["mathematician.solve", "mathematician.verify", "mathematician.model"],
  scientist: ["scientist.experiment.design", "scientist.evidence.review", "scientist.method.critique"],
  health: ["health.info.general", "health.info.safety", "health.care_navigation"],
};

const roleSummaries = Object.entries(rolesByGroup).flatMap(([groupId, roleIds]) =>
  roleIds.map((roleId) => ({
    id: roleId,
    label: label(roleId),
    primaryGroupId: groupId,
    secondaryGroupIds: secondaryGroups[roleId] ?? [],
  })),
);

export const compactTaxonomy: CompactTaxonomy = {
  manifest: {
    taxonomyVersion: "1.0.0-alpha.1",
    contentRevision: "taxonomy-v1-alpha.1",
    classificationContractVersion: "role-model.classification.v1",
    counts: {
      groups: Object.keys(rolesByGroup).length,
      roles: roleSummaries.length,
      tasks: Object.values(roleTaskIds).reduce((sum, taskIds) => sum + taskIds.length, 0),
    },
  },
  groups: [
    {
      id: "engineering",
      label: "Engineering",
      primaryRoleIds: rolesByGroup.engineering,
      secondaryRoleIds: [],
    },
    {
      id: "product_design",
      label: "Product And Design",
      primaryRoleIds: rolesByGroup.product_design,
      secondaryRoleIds: [],
    },
    {
      id: "knowledge_research",
      label: "Knowledge And Research",
      primaryRoleIds: rolesByGroup.knowledge_research,
      secondaryRoleIds: ["health"],
    },
    {
      id: "business",
      label: "Business",
      primaryRoleIds: rolesByGroup.business,
      secondaryRoleIds: ["legal", "recruiter"],
    },
    {
      id: "communication",
      label: "Communication",
      primaryRoleIds: rolesByGroup.communication,
      secondaryRoleIds: [],
    },
    {
      id: "governance_safety",
      label: "Governance And Safety",
      primaryRoleIds: rolesByGroup.governance_safety,
      secondaryRoleIds: ["security", "finance"],
    },
  ],
  roleSummaries,
  roleTaskIndex: Object.fromEntries(
    Object.entries(roleTaskIds).map(([roleId, taskIds]) => [
      roleId,
      taskIds.map((id) => ({ id, label: label(id) })),
    ]),
  ),
};
