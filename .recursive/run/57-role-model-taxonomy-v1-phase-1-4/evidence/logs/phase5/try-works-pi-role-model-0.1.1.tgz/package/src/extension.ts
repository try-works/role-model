import { createFileAliasStore } from "./alias-store.js";
import { type RoleModelCommandDependencies, createRoleModelCommandHandler } from "./commands.js";
import { registerRoleModelProvider } from "./provider-registration.js";
import { injectRoleModelIntentIntoPayload } from "./request-intent.js";
import { discoverRoleModelRuntime } from "./runtime-discovery.js";
import type { DownstreamOpenAIDiscovery } from "./types.js";
import type { PiCommandContext, PiExtensionAPI } from "./types.js";

export interface RoleModelExtensionOptions extends Partial<RoleModelCommandDependencies> {
  endpoint?: string;
  allowRemote?: boolean;
  aliasStorePath?: string;
}

export function createRoleModelExtension(options: RoleModelExtensionOptions = {}) {
  return async function roleModelExtension(pi: PiExtensionAPI): Promise<void> {
    const roleModelAliasIds = new Set<string>();
    const rememberAliases = (discovery: DownstreamOpenAIDiscovery) => {
      roleModelAliasIds.clear();
      for (const model of discovery.models) {
        if (model.type === "alias") roleModelAliasIds.add(model.id);
      }
    };
    const discover =
      options.discover ??
      (() => {
        return discoverRoleModelRuntime({
          ...(options.endpoint ? { endpoint: options.endpoint } : {}),
          ...(options.allowRemote === undefined ? {} : { allowRemote: options.allowRemote }),
        });
      });

    try {
      const result = await discover();
      rememberAliases(result.discovery);
      registerRoleModelProvider(pi, result.discovery);
    } catch {
      // Pi should still load the command so `/role-model doctor` can explain endpoint failures.
    }

    const aliasStore =
      options.readSelectedAlias || options.writeSelectedAlias
        ? undefined
        : createFileAliasStore(options.aliasStorePath);

    const command = createRoleModelCommandHandler({
      discover,
      refreshProvider: (discovery) => {
        rememberAliases(discovery);
        registerRoleModelProvider(pi, discovery);
      },
      readSelectedAlias: options.readSelectedAlias ?? aliasStore?.readSelectedAlias,
      writeSelectedAlias: options.writeSelectedAlias ?? aliasStore?.writeSelectedAlias,
      setActiveModel:
        options.setActiveModel ??
        (pi.setModel ? (model) => pi.setModel?.(model) ?? Promise.resolve(false) : undefined),
    });

    pi.on?.("before_provider_request", (event) =>
      injectRoleModelIntentIntoPayload(event.payload, roleModelAliasIds),
    );

    pi.registerCommand("role-model", {
      description: "Configure and inspect the Role-Model provider for Pi.",
      async handler(args = "", context?: PiCommandContext) {
        const result = await command(args);
        context?.ui?.notify?.(result.text, result.ok ? "info" : "error");
      },
    });
  };
}

export default createRoleModelExtension();
