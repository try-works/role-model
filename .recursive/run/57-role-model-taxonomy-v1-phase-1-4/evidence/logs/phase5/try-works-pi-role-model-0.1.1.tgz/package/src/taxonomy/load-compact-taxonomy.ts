import { compactTaxonomy, type CompactTaxonomy } from "./compact-data.js";

export function loadCompactTaxonomy(): CompactTaxonomy {
  return compactTaxonomy;
}
