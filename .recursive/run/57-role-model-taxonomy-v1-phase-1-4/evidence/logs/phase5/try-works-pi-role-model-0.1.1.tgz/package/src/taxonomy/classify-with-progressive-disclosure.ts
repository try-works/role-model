import { loadCompactTaxonomy } from "./load-compact-taxonomy.js";

export interface ProgressiveClassificationInput {
  readonly prompt: string;
}

export interface ProgressiveClassification {
  readonly role_model: {
    readonly intent: {
      readonly taxonomyVersion: string;
      readonly classificationContractVersion: string;
      readonly role?: { readonly id: string; readonly hard: boolean };
      readonly task?: { readonly id: string; readonly hard: boolean };
      readonly capabilities: {
        readonly preferred: readonly string[];
      };
      readonly modalities: {
        readonly required: readonly string[];
      };
      readonly toolClasses: readonly string[];
      readonly source: "heuristic";
      readonly confidence: number;
      readonly evidence: readonly string[];
      readonly alternatives: readonly { readonly roleId: string; readonly taskType: string }[];
    };
  };
  readonly loadedChunks: readonly string[];
  readonly hiddenModelCallUsed: false;
}

const rules: readonly {
  readonly pattern: RegExp;
  readonly evidence: string;
  readonly roleId: string;
  readonly taskType: string;
  readonly capabilities: readonly string[];
  readonly toolClasses: readonly string[];
}[] = [
  {
    pattern: /\b(implement|bug fix|fix|patch|regression test)\b/i,
    evidence: "implementation/fix signal",
    roleId: "coder",
    taskType: "coder.edit",
    capabilities: ["code.read", "code.write"],
    toolClasses: ["filesystem.read", "filesystem.write", "shell.execute"],
  },
  {
    pattern: /\b(security|risk|vulnerab|threat|diff)\b/i,
    evidence: "security/risk/diff signal",
    roleId: "security",
    taskType: "security.audit",
    capabilities: ["security.analysis", "code.read"],
    toolClasses: ["filesystem.read"],
  },
  {
    pattern: /\b(current|public documentation|cite|compare|sources?)\b/i,
    evidence: "current research/citation signal",
    roleId: "researcher",
    taskType: "researcher.web_research.current",
    capabilities: ["web.search", "citation.synthesis"],
    toolClasses: ["web.search", "http.fetch"],
  },
  {
    pattern: /\b(support notes|customer reply|ticket|apology)\b/i,
    evidence: "support communication signal",
    roleId: "support",
    taskType: "support.ticket.reply",
    capabilities: ["communication.user_facing"],
    toolClasses: [],
  },
  {
    pattern: /\b(schema|migration plan|api design|architecture)\b/i,
    evidence: "architecture/schema migration signal",
    roleId: "architect",
    taskType: "architect.migration.strategy",
    capabilities: ["reasoning.multi_step", "data.schema"],
    toolClasses: [],
  },
  {
    pattern: /\b(product requirements|acceptance criteria|workflow)\b/i,
    evidence: "product requirements signal",
    roleId: "product",
    taskType: "product.requirements",
    capabilities: ["reasoning.multi_step"],
    toolClasses: [],
  },
];

export function classifyWithProgressiveDisclosure(
  input: ProgressiveClassificationInput,
): ProgressiveClassification {
  const taxonomy = loadCompactTaxonomy();
  const normalizedPrompt = input.prompt.trim();
  const match = rules.find((rule) => rule.pattern.test(normalizedPrompt)) ?? rules[1];
  const roleTasks = taxonomy.roleTaskIndex[match.roleId] ?? [];
  const alternatives = roleTasks
    .filter((task) => task.id !== match.taskType)
    .slice(0, 2)
    .map((task) => ({ roleId: match.roleId, taskType: task.id }));

  return {
    role_model: {
      intent: {
        taxonomyVersion: taxonomy.manifest.taxonomyVersion,
        classificationContractVersion: taxonomy.manifest.classificationContractVersion,
        role: { id: match.roleId, hard: false },
        task: { id: match.taskType, hard: false },
        capabilities: { preferred: match.capabilities },
        modalities: { required: ["text"] },
        toolClasses: match.toolClasses,
        source: "heuristic",
        confidence: 0.72,
        evidence: [match.evidence],
        alternatives,
      },
    },
    loadedChunks: ["groups", `roles:${match.roleId}`, `tasks:${match.roleId}`],
    hiddenModelCallUsed: false,
  };
}
